-- Changes amount of decimal places shown on the mod. defaults to 0. If higher than 4, will round down. If lower than 0, will round up.
coordinates.significantdigits = 0
-- defaults to false. Allows for z coordinates to show up.
coordinates.showz = false