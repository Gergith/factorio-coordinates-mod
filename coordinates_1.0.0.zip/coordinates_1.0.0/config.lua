-- defaults to 4. If higher than 4, will round down. If lower than 0, will round up.
coordinates.significantdigits = 4